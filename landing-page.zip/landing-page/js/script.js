// Platform detection
function detectPlatform() {
    const userAgent = navigator.userAgent.toLowerCase();
    const platform = navigator.platform.toLowerCase();

    let os = 'unknown';
    let arch = 'unknown';

    // Detect OS
    if (userAgent.includes('mac') || platform.includes('mac')) {
        os = 'macos';
        // Detect Apple Silicon vs Intel
        // Check for Apple Silicon indicators
        if (navigator.userAgentData && navigator.userAgentData.platform === 'macOS') {
            // Modern browsers might have more info
            arch = 'arm'; // Default to ARM for newer Macs
        } else if (platform.includes('arm') || userAgent.includes('arm')) {
            arch = 'arm';
        } else {
            // Heuristic: newer macOS versions are more likely ARM
            arch = 'arm'; // Default to ARM since most new Macs are Apple Silicon
        }
    } else if (userAgent.includes('win') || platform.includes('win')) {
        os = 'windows';
        arch = 'x64';
    } else if (userAgent.includes('linux') || platform.includes('linux')) {
        os = 'linux';
        arch = 'x64';
    }

    return { os, arch };
}

function getDownloadInfo(platform) {
    const downloads = {
        'macos-arm': {
            url: 'https://github.com/tayyab-nlp/AnnotaLoop/releases/latest/download/AnnotaLoop_aarch64.dmg',
            text: 'Download for macOS',
            hint: 'Detected macOS (Apple Silicon)'
        },
        'macos-intel': {
            url: 'https://github.com/tayyab-nlp/AnnotaLoop/releases/latest/download/AnnotaLoop_x64.dmg',
            text: 'Download for macOS',
            hint: 'Detected macOS (Intel)'
        },
        'windows': {
            url: 'https://github.com/tayyab-nlp/AnnotaLoop/releases/latest/download/AnnotaLoop_x64-setup.exe',
            text: 'Download for Windows',
            hint: 'Detected Windows'
        },
        'linux': {
            url: 'https://github.com/tayyab-nlp/AnnotaLoop/releases/latest/download/AnnotaLoop_amd64.AppImage',
            text: 'Download for Linux',
            hint: 'Detected Linux'
        },
        'unknown': {
            url: 'https://github.com/tayyab-nlp/AnnotaLoop/releases',
            text: 'Download Free',
            hint: ''
        }
    };

    if (platform.os === 'macos') {
        return platform.arch === 'arm' ? downloads['macos-arm'] : downloads['macos-intel'];
    }
    return downloads[platform.os] || downloads['unknown'];
}

// Initialize Lucide icons
document.addEventListener('DOMContentLoaded', function () {
    lucide.createIcons();

    // Platform detection and download button setup
    const platform = detectPlatform();
    const downloadInfo = getDownloadInfo(platform);

    // Update hero download button
    const primaryDownload = document.getElementById('primary-download');
    const downloadText = document.getElementById('download-text');
    const detectedPlatform = document.getElementById('detected-platform');
    const macosSetupLink = document.getElementById('macos-setup-link');

    if (primaryDownload && downloadText) {
        primaryDownload.href = downloadInfo.url;
        downloadText.textContent = downloadInfo.text;
    }

    if (detectedPlatform && downloadInfo.hint) {
        detectedPlatform.textContent = downloadInfo.hint;
    }

    // Show macOS setup link if on macOS
    if (platform.os === 'macos' && macosSetupLink) {
        macosSetupLink.style.display = 'inline-flex';
    }

    // Update download section button
    const downloadPrimaryBtn = document.getElementById('download-primary-btn');
    const downloadPrimaryText = document.getElementById('download-primary-text');
    const detectedHint = document.getElementById('detected-hint');

    if (downloadPrimaryBtn && downloadPrimaryText) {
        downloadPrimaryBtn.href = downloadInfo.url;
        downloadPrimaryText.textContent = downloadInfo.text;
    }

    if (detectedHint && downloadInfo.hint) {
        detectedHint.textContent = downloadInfo.hint;
    }

    // Toggle other platforms visibility
    const otherPlatformsToggle = document.getElementById('other-platforms-toggle');
    const otherPlatforms = document.getElementById('other-platforms');

    if (otherPlatformsToggle && otherPlatforms) {
        otherPlatformsToggle.addEventListener('click', function () {
            otherPlatforms.classList.toggle('active');
            this.textContent = otherPlatforms.classList.contains('active')
                ? 'Hide other platforms'
                : 'Not your platform? View all options';
        });
    }

    // Mobile nav toggle
    const navToggle = document.getElementById('nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle) {
        navToggle.addEventListener('click', function () {
            navLinks.classList.toggle('active');
        });
    }

    // Header scroll effect
    const header = document.getElementById('header');

    window.addEventListener('scroll', function () {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Video modal
    const videoModal = document.getElementById('video-modal');
    const videoPlayer = document.getElementById('video-player');
    const videoClose = document.getElementById('video-close');
    const tutorialCards = document.querySelectorAll('.tutorial-card');

    function openVideoModal(videoSrc) {
        if (videoSrc && videoModal && videoPlayer) {
            videoPlayer.querySelector('source').src = videoSrc;
            videoPlayer.load();
            videoModal.classList.add('active');
            document.body.style.overflow = 'hidden';
            videoPlayer.play().catch(function (e) {
                console.log('Autoplay prevented:', e);
            });
        }
    }

    function closeVideoModal() {
        if (videoModal && videoPlayer) {
            videoModal.classList.remove('active');
            document.body.style.overflow = '';
            videoPlayer.pause();
            videoPlayer.currentTime = 0;
        }
    }

    // Handle tutorial card clicks
    tutorialCards.forEach(function (card) {
        card.addEventListener('click', function () {
            const videoSrc = this.dataset.video;
            openVideoModal(videoSrc);
        });
    });

    // Handle URL hash for direct video links (from app)
    function checkUrlHash() {
        const hash = window.location.hash;
        if (hash) {
            const videoId = hash.substring(1);
            const targetCard = document.getElementById(videoId);
            if (targetCard) {
                const videoSrc = targetCard.dataset.video;
                if (videoSrc) {
                    setTimeout(function () {
                        openVideoModal(videoSrc);
                    }, 500);
                }
            }
        }
    }

    checkUrlHash();
    window.addEventListener('hashchange', checkUrlHash);

    // Close video modal
    if (videoClose) {
        videoClose.addEventListener('click', closeVideoModal);
    }

    if (videoModal) {
        videoModal.addEventListener('click', function (e) {
            if (e.target === videoModal) {
                closeVideoModal();
            }
        });
    }

    // macOS setup modal
    const setupModal = document.getElementById('setup-modal');
    const setupModalClose = document.getElementById('setup-modal-close');

    function openSetupModal() {
        if (setupModal) {
            setupModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeSetupModal() {
        if (setupModal) {
            setupModal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    if (macosSetupLink) {
        macosSetupLink.addEventListener('click', openSetupModal);
    }

    if (setupModalClose) {
        setupModalClose.addEventListener('click', closeSetupModal);
    }

    if (setupModal) {
        setupModal.addEventListener('click', function (e) {
            if (e.target === setupModal) {
                closeSetupModal();
            }
        });
    }

    // Close modals on Escape key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            if (videoModal && videoModal.classList.contains('active')) {
                closeVideoModal();
            }
            if (setupModal && setupModal.classList.contains('active')) {
                closeSetupModal();
            }
        }
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href.startsWith('#video-')) return;
            if (href === '#') return;

            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                const headerHeight = header.offsetHeight;
                const targetPosition = target.offsetTop - headerHeight - 20;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);

    document.querySelectorAll('.feature-card, .tutorial-card, .use-case').forEach(function (el) {
        el.classList.add('animate-on-scroll');
        observer.observe(el);
    });

    // Load video thumbnails
    document.querySelectorAll('.thumbnail-video').forEach(function (video) {
        video.addEventListener('loadeddata', function () {
            this.currentTime = 1;
        });
    });

    // Re-initialize icons after dynamic content
    setTimeout(function () {
        lucide.createIcons();
    }, 100);
});

// Add animation styles dynamically
const style = document.createElement('style');
style.textContent = `
    .animate-on-scroll {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.5s ease, transform 0.5s ease;
    }
    
    .animate-on-scroll.visible {
        opacity: 1;
        transform: translateY(0);
    }
    
    .header.scrolled {
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }
    
    @media (max-width: 768px) {
        .nav-links {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            flex-direction: column;
            padding: 20px;
            gap: 16px;
            display: none;
            border-bottom: 1px solid var(--border);
        }
        
        .nav-links.active {
            display: flex;
        }
    }
`;
document.head.appendChild(style);
